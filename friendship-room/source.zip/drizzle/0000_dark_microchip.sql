CREATE TABLE `messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text NOT NULL,
	`session_id` text NOT NULL,
	`nickname` text NOT NULL,
	`avatar` text NOT NULL,
	`room` text NOT NULL,
	`body` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `messages_room_id` ON `messages` (`room`,`id`);--> statement-breakpoint
CREATE INDEX `messages_user_time` ON `messages` (`user_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`nickname` text NOT NULL,
	`avatar` text NOT NULL,
	`mood` text NOT NULL,
	`room` text NOT NULL,
	`last_seen` integer NOT NULL,
	`typing_until` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);
