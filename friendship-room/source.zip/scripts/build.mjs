import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const assets={};const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.webp':'image/webp','.woff2':'font/woff2','.svg':'image/svg+xml'};
for(const file of await fs.readdir('public')){const binary=['.webp','.woff2'].includes(path.extname(file));const b=await fs.readFile('public/'+file);assets['/'+file]={body:binary?b.toString('base64'):b.toString('utf8'),encoding:binary?'base64':'utf-8',type:types[path.extname(file)]||'application/octet-stream'};}
for(const file of ['/app.js','/style.css']){const hash=createHash('sha256').update(assets[file].body).digest('hex').slice(0,12);assets['/index.html'].body=assets['/index.html'].body.replaceAll('\"'+file+'\"','\"'+file+'?v='+hash+'\"');}
await fs.mkdir('dist/server',{recursive:true});await fs.mkdir('dist/.openai',{recursive:true});
await fs.writeFile('dist/server/index.js','const ASSETS='+JSON.stringify(assets)+';\n'+await fs.readFile('worker/index.js','utf8'));
await fs.copyFile('.openai/hosting.json','dist/.openai/hosting.json');await fs.cp('drizzle','dist/drizzle',{recursive:true});
console.log('Built Friendship Room worker with',Object.keys(assets).length,'assets');
