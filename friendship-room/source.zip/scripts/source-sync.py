import os,sys,json,subprocess,base64
if sys.stdin.isatty():
 import termios
 attrs=termios.tcgetattr(sys.stdin);attrs[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,attrs)
print('Ready for source credential on stdin (input hidden).',flush=True)
credential=json.loads(sys.stdin.readline())
env=os.environ.copy();token=credential.get('token')
if token:
 env['GIT_CONFIG_COUNT']='1';env['GIT_CONFIG_KEY_0']='http.extraHeader';env['GIT_CONFIG_VALUE_0']='Authorization: Bearer '+token
root=os.getcwd()
def run(args,capture=False):
 r=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE if capture else sys.stdout,stderr=sys.stderr,check=True)
 return r.stdout.strip() if capture else None
if not os.path.isdir('.git'):run(['git','init','-b',credential['branch']])
run(['git','config','user.name','eVora Studio']);run(['git','config','user.email','studio@evora.local'])
if 'origin' not in run(['git','remote'],True).split():run(['git','remote','add','origin',credential['remote_url']])
remote=run(['git','ls-remote','origin','refs/heads/'+credential['branch']],True)
if remote and not run(['git','log','--oneline','-1'],True):raise RuntimeError('Remote source exists; open it before syncing.')
run(['git','add','.']);run(['git','commit','-m','Build Aero Friendship Room with shared chat and presence'])
run(['git','push','-u','origin',credential['branch']])
print(json.dumps({'project_id':'appgprj_6af2a9cc22b481919e4a1604c47d3df5','commit_sha':run(['git','rev-parse','HEAD'],True)}))
