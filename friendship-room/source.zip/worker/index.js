const ROOM_IDS=new Set(['lounge','sunroom','garden']);
const AVATARS=new Set(['leaf','sun','water','cloud','flower','fish']);
const MOODS=new Set(['happy','cozy','curious','quiet']);
const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const digest=async token=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(b=>b.toString(16).padStart(2,'0')).join('');
const cookieToken=req=>(req.headers.get('Cookie')||'').split(';').map(p=>p.trim()).find(p=>p.startsWith('__Host-evora-room='))?.slice(18)||null;
async function session(req,env,user){const token=cookieToken(req);if(!token)return null;const row=await env.DB.prepare('SELECT * FROM sessions WHERE id = ? AND user_id = ?').bind(await digest(token),user).first();return row;}
async function data(req){if(!req.headers.get('Content-Type')?.includes('application/json'))throw new Error('Please send a JSON request.');const raw=await req.text();if(raw.length>4096)throw new Error('That message is too long.');try{return JSON.parse(raw);}catch{throw new Error('That request could not be read.');}}
export async function api(req,env){
 const url=new URL(req.url);const user=req.headers.get('oai-authenticated-user-id');
 if(!user)return json({error:'Sign in to join the room.'},401);
 if(!env.DB)return json({error:'The room is getting ready. Please try again shortly.'},503);
 if(req.method==='POST'&&req.headers.get('Origin')!==url.origin)return json({error:'Please send this from the room.'},403);
 const now=Date.now();
 try{
  if(url.pathname==='/api/join'&&req.method==='POST'){
   const input=await data(req);const nickname=String(input.nickname||'').trim();
   if(!/^[\p{L}\p{N} ._'\-]{2,24}$/u.test(nickname))return json({error:'Choose a nickname with 2–24 letters, numbers, spaces or simple punctuation.'},400);
   const avatar=AVATARS.has(input.avatar)?input.avatar:'leaf';const mood=MOODS.has(input.mood)?input.mood:'happy';const room=ROOM_IDS.has(input.room)?input.room:'lounge';
   const token=crypto.randomUUID()+crypto.randomUUID();const id=await digest(token);const old=await session(req,env,user);
   const commands=[];if(old)commands.push(env.DB.prepare('DELETE FROM sessions WHERE id = ? AND user_id = ?').bind(old.id,user));
   commands.push(env.DB.prepare('DELETE FROM sessions WHERE last_seen < ?').bind(now-86400000));
   commands.push(env.DB.prepare('INSERT INTO sessions (id,user_id,nickname,avatar,mood,room,last_seen,typing_until,created_at) VALUES (?,?,?,?,?,?,?,0,?)').bind(id,user,nickname,avatar,mood,room,now,now));
   await env.DB.batch(commands);
   return json({ok:true,nickname,avatar,mood,room},200,{'Set-Cookie':`__Host-evora-room=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=86400`});
  }
  const current=await session(req,env,user);if(!current)return json({error:'Choose a nickname to enter the room.',joinRequired:true},401);
  if(url.pathname==='/api/state'&&req.method==='GET'){
   const room=ROOM_IDS.has(url.searchParams.get('room'))?url.searchParams.get('room'):current.room;
   const result=await env.DB.prepare('SELECT id,nickname,avatar,body,created_at,session_id FROM messages WHERE room = ? ORDER BY id DESC LIMIT 60').bind(room).all();
   const presence=await env.DB.prepare('SELECT id,nickname,avatar,mood,room,typing_until FROM sessions WHERE last_seen > ? ORDER BY created_at').bind(now-60000).all();
   return json({room,messages:result.results.reverse().map(m=>({id:m.id,nickname:m.nickname,avatar:m.avatar,body:m.body,createdAt:m.created_at,mine:m.session_id===current.id})),people:presence.results.map(p=>({nickname:p.nickname,avatar:p.avatar,mood:p.mood,room:p.room,mine:p.id===current.id,typing:p.typing_until>now})),me:{nickname:current.nickname,avatar:current.avatar,mood:current.mood,room:current.room}});
  }
  if(url.pathname==='/api/heartbeat'&&req.method==='POST'){
   const input=await data(req);const room=ROOM_IDS.has(input.room)?input.room:current.room;const mood=MOODS.has(input.mood)?input.mood:current.mood;
   await env.DB.prepare('UPDATE sessions SET last_seen=?, room=?, mood=?, typing_until=? WHERE id=? AND user_id=?').bind(now,room,mood,input.typing?now+4000:0,current.id,user).run();return json({ok:true});
  }
  if(url.pathname==='/api/messages'&&req.method==='POST'){
   const input=await data(req);const body=typeof input.body==='string'?input.body.trim():'';const room=ROOM_IDS.has(input.room)?input.room:current.room;
   if(!body||[...body].length>500)return json({error:'Write a message between 1 and 500 characters.'},400);
   const recent=await env.DB.prepare('SELECT COUNT(*) AS count, MAX(created_at) AS latest FROM messages WHERE user_id=? AND created_at>?').bind(user,now-60000).first();
   if(recent.count>=20||recent.latest&&now-recent.latest<1000)return json({error:'Take a breath. You can send another message in a moment.'},429);
   await env.DB.batch([env.DB.prepare('INSERT INTO messages (user_id,session_id,nickname,avatar,room,body,created_at) VALUES (?,?,?,?,?,?,?)').bind(user,current.id,current.nickname,current.avatar,room,body,now),env.DB.prepare('UPDATE sessions SET last_seen=?, room=?, typing_until=0 WHERE id=?').bind(now,room,current.id)]);
   return json({ok:true},201);
  }
  if(url.pathname==='/api/leave'&&req.method==='POST'){await env.DB.prepare('DELETE FROM sessions WHERE id=? AND user_id=?').bind(current.id,user).run();return json({ok:true},200,{'Set-Cookie':'__Host-evora-room=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0'});}
  return json({error:'That action is not available.'},404);
 }catch(error){if(error.message?.startsWith('Please')||error.message?.startsWith('That'))return json({error:error.message},400);return json({error:'The room had a connection hiccup. Please try again.'},500);}
}
export default {async fetch(req,env){const url=new URL(req.url);if(url.pathname.startsWith('/api/'))return api(req,env);if(req.method!=='GET'&&req.method!=='HEAD')return new Response('Method not allowed',{status:405});const asset=ASSETS[url.pathname==='/'?'/index.html':url.pathname];if(!asset)return new Response('Not found',{status:404});return new Response(req.method==='HEAD'?null:asset.encoding==='base64'?Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)):asset.body,{headers:{'Content-Type':asset.type,'Cache-Control':url.pathname==='/'?'no-cache':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'"}});}};
